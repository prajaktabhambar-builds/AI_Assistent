# 🤖 AI Assistant

A simple responsive AI Assistant web project for answering user queries related to **education, career and general help**.

## Features
- Chat interface
- Education assistance
- Career guidance
- General help
- Quick question buttons
- New Chat
- Responsive premium dark UI
- Student profile

## Technologies
- HTML5
- CSS3
- JavaScript

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Or open the folder in VS Code and use Live Server.

## Note
This is a frontend AI-assistant prototype. The response engine is implemented in JavaScript. A real generative AI API can be connected later for open-ended answers.

## Developer
Prajakta Bhambar
