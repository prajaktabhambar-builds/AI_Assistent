const input=document.getElementById("input"), messages=document.getElementById("messages");

const responses=[
  {keys:["python"],answer:"Python is a high-level, easy-to-learn programming language. It is widely used for web development, automation, data science, artificial intelligence and machine learning."},
  {keys:["artificial intelligence","what is ai"," ai "],answer:"Artificial Intelligence (AI) is a technology that enables computers to perform tasks that normally require human intelligence, such as learning, problem-solving, understanding language and recognizing patterns."},
  {keys:["career","job","career options"],answer:"After Computer Engineering, you can explore Software Development, Web Development, Data Analytics, AI/ML, Cybersecurity, Cloud Computing, DevOps and IoT. Choose based on your interests and skills."},
  {keys:["study","exam","study tips"],answer:"For exams, divide the syllabus into small topics, make short notes, practice previous questions, revise regularly and use active recall. Focus first on high-weightage topics."},
  {keys:["html"],answer:"HTML stands for HyperText Markup Language. It is used to create the structure of web pages, such as headings, paragraphs, buttons, forms and images."},
  {keys:["javascript"],answer:"JavaScript is a programming language used to make websites interactive. It can handle events, manipulate webpage content, validate forms and build web applications."},
  {keys:["resume","cv"],answer:"A good student resume should include your contact details, career objective, education, technical skills, projects, internships/certificates and achievements. Keep it clear and preferably one page."},
  {keys:["hello","hi","hey"],answer:"Hello Prajakta! 👋 I'm your AI Assistant. You can ask me about education, career, programming or general topics."},
  {keys:["general help","help"],answer:"Sure! I can help with study planning, programming concepts, career guidance, project ideas, resumes, interview preparation and general questions."}
];

function getAnswer(q){
 const lower=q.toLowerCase();
 for(const r of responses){if(r.keys.some(k=>lower.includes(k))) return r.answer;}
 return "I can help with education, career and general questions. Try asking: “What is Python?”, “Which career is best after Computer Engineering?”, “Give me study tips”, or “What is AI?”";
}
function addUser(text){messages.innerHTML+=`<div class="user">${escapeHtml(text)}</div>`;scroll()}
function addAI(text){messages.innerHTML+=`<div class="message ai"><div class="bot">✦</div><div><b>AI Assistant</b><p>${text}</p></div></div>`;scroll()}
function send(){const q=input.value.trim();if(!q)return;addUser(q);input.value="";setTimeout(()=>addAI(getAnswer(q)),350)}
function quick(q){input.value=q;send()}
function newChat(){messages.innerHTML=`<div class="message ai"><div class="bot">✦</div><div><b>AI Assistant</b><p>New chat started. How can I help you, Prajakta? 👋</p></div></div>`;input.focus()}
function scroll(){messages.scrollTop=messages.scrollHeight}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
